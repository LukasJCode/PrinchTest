let numberOfQueries = 0;

//if the result is empty throws an error
function emptyResultError(result){
    if(result.length == 0)
        return true
    else
        return false;
}

//if its fifth query throws error
function islandicError(){
    numberOfQueries++;
    if(numberOfQueries % 5 == 0)
        return true;
    else
        return false;
}

//if its specified time interval throws error
function logicalError(){
    let date = new Date();
    if(((date.getSeconds() >= 4) && (date.getSeconds() <= 9)) || ((date.getSeconds() >= 29) && (date.getSeconds() <= 34)))
        return true;
    else
        return false;
}



exports.emptyResultError = emptyResultError;
exports.islandicError = islandicError;
exports.logicalError = logicalError;