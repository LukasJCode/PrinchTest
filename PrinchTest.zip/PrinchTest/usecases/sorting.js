
function sortCarsByColor(cars, color){
    return cars.filter(car => car.color === color)
}

function sortCarsByBrand(cars, brand){
    return cars.filter(car => car.brand == brand)
}

function sortCarsByDate(cars, year){
    return cars.filter(car => car.year == year)
}

function sortIslandicCarsByPrice(cars, price){
    var result = [];
    for(var i in cars){

        if(cars[i].islandic_weather_rentals_price == price)
            result.push(cars[i]);

    }

    return result;
}

function sortLogicalCarsByPrice(cars, price){
    var result = [];
    for(var i in cars){

        if(cars[i].smart_and_logical_company_price == price)
                result.push(cars[i]);

    }
    
    return result;
}

exports.sortCarsByColor = sortCarsByColor;
exports.sortCarsByBrand = sortCarsByBrand;
exports.sortCarsByDate = sortCarsByDate;
exports.sortIslandicCarsByPrice = sortIslandicCarsByPrice;
exports.sortLogicalCarsByPrice = sortLogicalCarsByPrice;

