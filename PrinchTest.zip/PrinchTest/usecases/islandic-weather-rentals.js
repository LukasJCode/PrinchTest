const request = require("request-promise");
const data = require("../data/car-data");
const url = "https://api.openweathermap.org/data/2.5/weather?q=reykjavik,is&appid=f25f50afbde90c058326b42390470c63";

let cars = data.readData();
getWeather();

async function getWeather()
{
    try{
        const weather = await request({url: url, json: true});
        //setting price after getting the weather data
        setPrice(calculatePrice(weather.main.temp, weather.wind.speed));
    }
    catch(error){
        console.log(error);
    }
}

function setPrice(price)
{
    for(let i in cars){
        cars[i]['islandic_weather_rentals_price'] = price;
    }
}

function getData()
{
    //Check current weather and update the price
    getWeather();
    return cars;
}

//calculating the price based on wind and temperature
function calculatePrice(temperature, wind){
    return Math.round(temperature * wind);
}

exports.getWeather = getWeather;
exports.getData = getData;
