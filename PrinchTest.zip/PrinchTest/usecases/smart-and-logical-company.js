const data = require("../data/car-data");
const fs = require("fs");
//June 5th Denmarks national day
const denmarksNationalDay = new Date();
denmarksNationalDay.setMonth(5);
denmarksNationalDay.setDate(5);

let cars = [];
cars = data.readData();
setPrice(cars);

function setPrice(cars)
{
    for(let i in cars){
        cars[i]['smart_and_logical_company_price'] = calculatePrice(cars[i].weight, cars[i].horsepower, cars[i].color);
    }
}

function getData()
{
    return cars;
}

function calculatePrice(weight, horsepower, color){
    var price;
    //getting todays date
    const date = new Date();
    //checking if its saturday or Denmarks national day
    if(date.getDay() == 6 || (date.getMonth() == denmarksNationalDay.getMonth() && date.getDay() == denmarksNationalDay.getDay())){
        price = null;
    }
    else{
        price = calculateBasePrice(weight, horsepower, color);
    }
    return Math.round(price);
}

//calculating base price of the car based on weight, horsepower and color
function calculateBasePrice(weight, horsepower, color){
    var result = weight + horsepower;
    if(color == "black"){
        result = result + percentage(result, 15);
    }
    else if(color == "red"){
        result = result - percentage(result, 5);
    }
    return result;
}

function percentage(total, numberOfPercentage)
{
    return (total * numberOfPercentage) / 100;
}

exports.setPrice = setPrice;
exports.getData = getData;