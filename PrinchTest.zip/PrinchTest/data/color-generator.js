const colors = ["red", "blue", "black"];
//generating random color for a car
function generateColor(){
    return colors[Math.floor(Math.random() * colors.length)]
}

exports.generateColor = generateColor;