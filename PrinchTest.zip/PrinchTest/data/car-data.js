const fs = require("fs");
const colorGenerator = require("./color-generator");

let cars = [];

function readData(){
    //getting data from json file
    let rawdata = fs.readFileSync("data/cars.json");
    cars = JSON.parse(rawdata);
    //setting color field for each car
    setColorField(cars);
    return cars;
}

function setColorField(cars){
    for(let i in cars) 
    {
        cars[i]['color'] = colorGenerator.generateColor();
    }
}

exports.readData = readData;