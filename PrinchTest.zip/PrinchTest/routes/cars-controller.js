const router = require("express").Router();
const data = require("../data/car-data");
const sorting = require("../usecases/sorting");
const islandicWeatherRentals = require("../usecases/islandic-weather-rentals");
const smartAndLogicalCompany = require("../usecases/smart-and-logical-company");
const errorHandler = require("../usecases/error-handler");

//get cars
router.route("/").get(function(req, res){
    const {color, brand, date} = req.query;
    //reading data from .json file
    let result = data.readData();
    //sort cars by color
    if(color){
        result = sorting.sortCarsByColor(result, req.query.color);
    }
    //sort cars by brand
    if(brand){
        result = sorting.sortCarsByBrand(result, req.query.brand);
    }
    //sort cars by date
    if(date)
    {
        result = sorting.sortCarsByDate(result, req.query.date);
    }
    //handle error if theres no results
    if(errorHandler.emptyResultError(result))
    {
        return res.status(404).json({error: "Couldnt find anything"});
    }

    res.send(result);
    
});

router.route("/islandic").get(function(req, res){
    //handle islandic cobol radiation error
    if(errorHandler.islandicError())
        return res.status(503).json({error: "Oops we had a bug in our old legacy software written in Cobol that happens due to cosmic radiation."});
    
    const {color, brand, price, date} = req.query;
    let result = islandicWeatherRentals.getData();
    //sort cars by color
    if(color){
        result = sorting.sortCarsByColor(result, req.query.color);
    }
    //sort cars by brand
    if(brand){
        result = sorting.sortCarsByBrand(result, req.query.brand);
    }
    //sort cars by date
    if(date)
    {
        result = sorting.sortCarsByDate(result, req.query.date);
    }
    //sort cars by price
    if(price)
    {
        result = sorting.sortIslandicCarsByPrice(result, req.query.price);
    }
    //handle error if theres no results
    if(errorHandler.emptyResultError(result))
    {
        return res.status(404).json({error: "Couldnt find anything"});
    }

    res.send(result);
})

router.route("/logical").get(function(req, res){
    //handle logical interval error
    if(errorHandler.logicalError())
    {
        return res.status(503).json({error: "Oops we are unresponsive during this time"});
    }

    const {color, brand, price, date} = req.query;
    let result = smartAndLogicalCompany.getData();
    //sort cars by color
    if(color){
        result = sorting.sortCarsByColor(result, req.query.color);
    }
    //sort cars by brand
    if(brand){
        result = sorting.sortCarsByBrand(result, req.query.brand);
    }
    //sort cars by date
    if(date)
    {
        result = sorting.sortCarsByDate(result, req.query.date);
    }
    //sort cars by price
    if(price)
    {
        result = sorting.sortLogicalCarsByPrice(result, req.query.price);
    }

    //handle error if theres no results
    if(errorHandler.emptyResultError(result))
    {
        return res.status(404).json({error: "Couldnt find anything"});
    }

    res.send(result);
})

module.exports = router;