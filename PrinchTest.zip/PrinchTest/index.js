const express = require("express");
const app = express();
const port = 3000;

//Declaring routes used in api
const carsRouter = require("./routes/cars-controller");
app.use("/cars", carsRouter);

//Main page
app.get("/", function(req,res){
    res.send("Welcome to the Car Rental Finder");
})

//Running the server
app.listen(port, () => {
    console.log(`Example app listening on port ${port}!`);
});